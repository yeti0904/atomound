#include "language.hh"
#include "builtin.hh"

Language::LanguageComponents::LanguageComponents() {
	RegisterFunction({"print",  BuiltIn::Print});
	RegisterFunction({"return", BuiltIn::Return});
	RegisterFunction({"exit",   BuiltIn::Exit});
}

void Language::LanguageComponents::Init(std::vector <Lexer::Token> p_tokens) {
	tokens = p_tokens;
}

void Language::LanguageComponents::RegisterFunction(Function function) {
	functions.push_back(function);
}

void Language::LanguageComponents::JumpToLabel(std::string name) {
	for (size_t j = 0; i < tokens.size(); ++j) {
		if ((tokens[j].type == Lexer::TokenType::Label) && (tokens[j].content == name)) {
			i = j;
			return;
		}
	}
	fprintf(stderr, "[ERROR] Couldn't jump to label %s\n", name.c_str());
	exit(EXIT_FAILURE);
}
