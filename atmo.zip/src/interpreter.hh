#pragma once
#include "_components.hh"
#include "language.hh"

void Interpret(Language::LanguageComponents& lc);
