#pragma once

#define APP_TITLE   "atomound"
#define APP_VERSION "0.0.1"
