#pragma once

// C standard libraries
#include <stdio.h>
#include <ctype.h>

// C++ standard libraries
#include <string>
#include <vector>
#include <fstream>
#include <variant>
#include <algorithm>
