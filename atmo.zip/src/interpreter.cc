#include "interpreter.hh"

void Interpret(Language::LanguageComponents& lc) {
	for (lc.i = 0; lc.i < lc.tokens.size(); ++ lc.i) {
		auto& token = lc.tokens[lc.i];
		switch (token.type) {
			case Lexer::TokenType::Label:
			case Lexer::TokenType::End: {
				continue;
			}
			case Lexer::TokenType::FunctionCall: {
				while (lc.tokens[lc.i].type != Lexer::TokenType::End) {
					Language::Variable toPush;
					++ lc.i;
					if (lc.tokens[lc.i].type == Lexer::TokenType::End) {
						break;
					}
					switch (lc.tokens[lc.i].type) {
						case Lexer::TokenType::String: {
							toPush.type  = Language::Type::String;
							toPush.value = lc.tokens[lc.i].content;
							break;
						}
						case Lexer::TokenType::Integer: {
							toPush.type  = Language::Type::Integer;
							toPush.value = std::stoi(lc.tokens[lc.i].content);
							break;
						}
						case Lexer::TokenType::Float: {
							toPush.type  = Language::Type::Float;
							toPush.value = std::stod(lc.tokens[lc.i].content);
							break;
						}
						case Lexer::TokenType::Bool: {
							toPush.type  = Language::Type::Bool;
							toPush.value = lc.tokens[lc.i].content == "true";
							break;
						}
						case Lexer::TokenType::Identifier: {
							bool exists = false;
							for (auto& var : lc.variables) {
								if (lc.tokens[lc.i].content == var.name) {
									exists = true;
									toPush = var;
									break;
								}
							}
							if (!exists) {
								fprintf(
									stderr,
									"[ERROR] Referenced undefined variable %s at %i:%i\n",
									lc.tokens[lc.i].content.c_str(),
									(int) lc.tokens[lc.i].line,
									(int) lc.tokens[lc.i].column
								);
								exit(EXIT_FAILURE);
							}
							break;
						}
						default: {
							printf("%i\n", (int) lc.i);
							fprintf(
								stderr, "[ERROR] (2) Unexpected token %s at %i:%i\n",
								Lexer::TypeAsString(token).c_str(),
								(int) lc.tokens[lc.i].line,
								(int) lc.tokens[lc.i].column
							);
							exit(EXIT_FAILURE);
						}
					}

					lc.passStack.push_back(toPush);
				}

				Language::Function function;
				bool               functionExists = false;
				bool               cxxFunction    = false;
				size_t             labelPos       = 0;
				for (auto& func : lc.functions) {
					if (func.name == token.content) {
						function       = func;
						functionExists = true;
						cxxFunction    = true;
					}
				}
				for (size_t i = 0; i < lc.tokens.size(); ++i) {
					if (
						(lc.tokens[i].type    == Lexer::TokenType::Label) &&
						(lc.tokens[i].content == token.content)
					) {
						functionExists = true;
						labelPos       = i;
					}
				}
				if (!functionExists) {
					fprintf(
						stderr,
						"[ERROR] Referenced undefined function %s at %i:%i\n",
						lc.tokens[lc.i].content.c_str(),
						(int) lc.tokens[lc.i].line,
						(int) lc.tokens[lc.i].column
					);
					exit(EXIT_FAILURE);
				}

				if (cxxFunction) {
					function.function(lc);
					lc.passStack = {};
				}
				else {
					lc.returnStack.push_back(lc.i);
					lc.i = labelPos;
				}
				break;
			}
			default: {
				fprintf(
					stderr, "[ERROR] (1) Unexpected token %s at %i:%i\n",
					Lexer::TypeAsString(token).c_str(),
					(int) token.line, (int) token.column
				);
				exit(EXIT_FAILURE);
			}
		}
	}
}
