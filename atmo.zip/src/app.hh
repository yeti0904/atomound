#pragma once
#include "_components.hh"

class App {
	public:
		// variables
		std::vector <std::string> args;

		// functions
		App(int argc, char** argv);
};
